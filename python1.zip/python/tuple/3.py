t=()
print(type(t))