t=(1,2,3)
print(t*3)